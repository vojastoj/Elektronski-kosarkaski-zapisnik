﻿
namespace Vojislav_Stojilkovic_Diplomski
{
    partial class Zapisnik
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.rtbA = new System.Windows.Forms.RichTextBox();
            this.btn1poenA = new System.Windows.Forms.Button();
            this.btn2poenaA = new System.Windows.Forms.Button();
            this.btn3poenaA = new System.Windows.Forms.Button();
            this.btnPonistiPoenA = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.cbTajm1 = new System.Windows.Forms.CheckBox();
            this.cbTajm2 = new System.Windows.Forms.CheckBox();
            this.cbTajm3 = new System.Windows.Forms.CheckBox();
            this.cbTajm4 = new System.Windows.Forms.CheckBox();
            this.cbTajm5 = new System.Windows.Forms.CheckBox();
            this.cbTajm6 = new System.Windows.Forms.CheckBox();
            this.cbTajm8 = new System.Windows.Forms.CheckBox();
            this.cbTajm7 = new System.Windows.Forms.CheckBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.rtbB = new System.Windows.Forms.RichTextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label26 = new System.Windows.Forms.Label();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.cb4 = new System.Windows.Forms.CheckBox();
            this.checkBox23 = new System.Windows.Forms.CheckBox();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.label25 = new System.Windows.Forms.Label();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.cb3 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.label24 = new System.Windows.Forms.Label();
            this.cb202 = new System.Windows.Forms.CheckBox();
            this.cb204 = new System.Windows.Forms.CheckBox();
            this.cb201 = new System.Windows.Forms.CheckBox();
            this.cb203 = new System.Windows.Forms.CheckBox();
            this.label23 = new System.Windows.Forms.Label();
            this.cb02 = new System.Windows.Forms.CheckBox();
            this.cb1 = new System.Windows.Forms.CheckBox();
            this.cb01 = new System.Windows.Forms.CheckBox();
            this.cb03 = new System.Windows.Forms.CheckBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.rtbPer1B = new System.Windows.Forms.RichTextBox();
            this.rtbPer1A = new System.Windows.Forms.RichTextBox();
            this.cbprvacet = new System.Windows.Forms.CheckBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.rtbPer2A = new System.Windows.Forms.RichTextBox();
            this.rtbPer2B = new System.Windows.Forms.RichTextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.rtbPer3A = new System.Windows.Forms.RichTextBox();
            this.rtbPer3B = new System.Windows.Forms.RichTextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.rtbPer4A = new System.Windows.Forms.RichTextBox();
            this.rtbPer4B = new System.Windows.Forms.RichTextBox();
            this.cbDrugaCet = new System.Windows.Forms.CheckBox();
            this.cbTrecaCet = new System.Windows.Forms.CheckBox();
            this.cbCetvrtaCet = new System.Windows.Forms.CheckBox();
            this.btnKonacanRez = new System.Windows.Forms.Button();
            this.label41 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.rtbKonacanA = new System.Windows.Forms.RichTextBox();
            this.rtbKonacanB = new System.Windows.Forms.RichTextBox();
            this.btnZatvori = new System.Windows.Forms.Button();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.label16 = new System.Windows.Forms.Label();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.checkBox22 = new System.Windows.Forms.CheckBox();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.checkBox26 = new System.Windows.Forms.CheckBox();
            this.checkBox27 = new System.Windows.Forms.CheckBox();
            this.checkBox28 = new System.Windows.Forms.CheckBox();
            this.checkBox29 = new System.Windows.Forms.CheckBox();
            this.checkBox30 = new System.Windows.Forms.CheckBox();
            this.checkBox31 = new System.Windows.Forms.CheckBox();
            this.checkBox32 = new System.Windows.Forms.CheckBox();
            this.checkBox33 = new System.Windows.Forms.CheckBox();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.rtbPrvaCetA = new System.Windows.Forms.RichTextBox();
            this.rtbDrugaCetA = new System.Windows.Forms.RichTextBox();
            this.rtbCetvrtaCetA = new System.Windows.Forms.RichTextBox();
            this.rtbTrecaCetA = new System.Windows.Forms.RichTextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.rtbCetvrtaCetB = new System.Windows.Forms.RichTextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.rtbTrecaCetB = new System.Windows.Forms.RichTextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.rtbDrugaCetB = new System.Windows.Forms.RichTextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.rtbPrvaCetB = new System.Windows.Forms.RichTextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(8, 78);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Sudija 1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(214, 24);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(38, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "Datum";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(396, 24);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 13);
            this.label7.TabIndex = 8;
            this.label7.Text = "Vreme";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 63);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 13);
            this.label8.TabIndex = 11;
            this.label8.Text = "Utakmica br.";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(15, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 13);
            this.label9.TabIndex = 10;
            this.label9.Text = "Takmičenje";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(81, 39);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(55, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Prvi sudija";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(39, 16);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(50, 13);
            this.label11.TabIndex = 7;
            this.label11.Text = "Tajm-auti";
            // 
            // label12
            // 
            this.label12.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor;
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(232, 179);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(48, 20);
            this.label12.TabIndex = 8;
            this.label12.Text = "Igrači";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(199, 74);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(45, 13);
            this.label14.TabIndex = 9;
            this.label14.Text = "Sudija 2";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(214, 63);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(36, 13);
            this.label15.TabIndex = 12;
            this.label15.Text = "Mesto";
            // 
            // rtbA
            // 
            this.rtbA.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbA.Location = new System.Drawing.Point(157, 717);
            this.rtbA.Name = "rtbA";
            this.rtbA.ReadOnly = true;
            this.rtbA.Size = new System.Drawing.Size(95, 79);
            this.rtbA.TabIndex = 14;
            this.rtbA.Text = "";
            // 
            // btn1poenA
            // 
            this.btn1poenA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btn1poenA.Location = new System.Drawing.Point(52, 717);
            this.btn1poenA.Name = "btn1poenA";
            this.btn1poenA.Size = new System.Drawing.Size(75, 23);
            this.btn1poenA.TabIndex = 16;
            this.btn1poenA.Text = "1 POEN";
            this.btn1poenA.UseVisualStyleBackColor = true;
            this.btn1poenA.Click += new System.EventHandler(this.btn1poenA_Click);
            // 
            // btn2poenaA
            // 
            this.btn2poenaA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btn2poenaA.Location = new System.Drawing.Point(52, 757);
            this.btn2poenaA.Name = "btn2poenaA";
            this.btn2poenaA.Size = new System.Drawing.Size(75, 23);
            this.btn2poenaA.TabIndex = 17;
            this.btn2poenaA.Text = "2 POENA";
            this.btn2poenaA.UseVisualStyleBackColor = true;
            this.btn2poenaA.Click += new System.EventHandler(this.btn2poenaA_Click);
            // 
            // btn3poenaA
            // 
            this.btn3poenaA.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btn3poenaA.Location = new System.Drawing.Point(52, 798);
            this.btn3poenaA.Name = "btn3poenaA";
            this.btn3poenaA.Size = new System.Drawing.Size(75, 23);
            this.btn3poenaA.TabIndex = 18;
            this.btn3poenaA.Text = "3 POENA";
            this.btn3poenaA.UseVisualStyleBackColor = true;
            this.btn3poenaA.Click += new System.EventHandler(this.btn3poenaA_Click);
            // 
            // btnPonistiPoenA
            // 
            this.btnPonistiPoenA.ForeColor = System.Drawing.Color.Red;
            this.btnPonistiPoenA.Location = new System.Drawing.Point(98, 847);
            this.btnPonistiPoenA.Name = "btnPonistiPoenA";
            this.btnPonistiPoenA.Size = new System.Drawing.Size(75, 23);
            this.btnPonistiPoenA.TabIndex = 19;
            this.btnPonistiPoenA.Text = "-1 POEN";
            this.btnPonistiPoenA.UseVisualStyleBackColor = true;
            this.btnPonistiPoenA.Click += new System.EventHandler(this.btnPonistiPoenA_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(100, 177);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(64, 20);
            this.label17.TabIndex = 20;
            this.label17.Text = "Ekipa A";
            // 
            // cbTajm1
            // 
            this.cbTajm1.AutoSize = true;
            this.cbTajm1.Location = new System.Drawing.Point(95, 70);
            this.cbTajm1.Name = "cbTajm1";
            this.cbTajm1.Size = new System.Drawing.Size(15, 14);
            this.cbTajm1.TabIndex = 21;
            this.cbTajm1.UseVisualStyleBackColor = true;
            this.cbTajm1.CheckedChanged += new System.EventHandler(this.cbTajm1_CheckedChanged);
            // 
            // cbTajm2
            // 
            this.cbTajm2.AutoSize = true;
            this.cbTajm2.Enabled = false;
            this.cbTajm2.Location = new System.Drawing.Point(116, 70);
            this.cbTajm2.Name = "cbTajm2";
            this.cbTajm2.Size = new System.Drawing.Size(15, 14);
            this.cbTajm2.TabIndex = 22;
            this.cbTajm2.UseVisualStyleBackColor = true;
            this.cbTajm2.CheckedChanged += new System.EventHandler(this.cbTajm2_CheckedChanged);
            // 
            // cbTajm3
            // 
            this.cbTajm3.AutoSize = true;
            this.cbTajm3.Location = new System.Drawing.Point(95, 93);
            this.cbTajm3.Name = "cbTajm3";
            this.cbTajm3.Size = new System.Drawing.Size(15, 14);
            this.cbTajm3.TabIndex = 23;
            this.cbTajm3.UseVisualStyleBackColor = true;
            this.cbTajm3.CheckedChanged += new System.EventHandler(this.cbTajm3_CheckedChanged);
            // 
            // cbTajm4
            // 
            this.cbTajm4.AutoSize = true;
            this.cbTajm4.Enabled = false;
            this.cbTajm4.Location = new System.Drawing.Point(116, 94);
            this.cbTajm4.Name = "cbTajm4";
            this.cbTajm4.Size = new System.Drawing.Size(15, 14);
            this.cbTajm4.TabIndex = 24;
            this.cbTajm4.UseVisualStyleBackColor = true;
            this.cbTajm4.CheckedChanged += new System.EventHandler(this.cbTajm4_CheckedChanged);
            // 
            // cbTajm5
            // 
            this.cbTajm5.AutoSize = true;
            this.cbTajm5.Enabled = false;
            this.cbTajm5.Location = new System.Drawing.Point(137, 94);
            this.cbTajm5.Name = "cbTajm5";
            this.cbTajm5.Size = new System.Drawing.Size(15, 14);
            this.cbTajm5.TabIndex = 25;
            this.cbTajm5.UseVisualStyleBackColor = true;
            this.cbTajm5.CheckedChanged += new System.EventHandler(this.cbTajm5_CheckedChanged);
            // 
            // cbTajm6
            // 
            this.cbTajm6.AutoSize = true;
            this.cbTajm6.Location = new System.Drawing.Point(95, 117);
            this.cbTajm6.Name = "cbTajm6";
            this.cbTajm6.Size = new System.Drawing.Size(15, 14);
            this.cbTajm6.TabIndex = 26;
            this.cbTajm6.UseVisualStyleBackColor = true;
            this.cbTajm6.CheckedChanged += new System.EventHandler(this.cbTajm6_CheckedChanged);
            // 
            // cbTajm8
            // 
            this.cbTajm8.AutoSize = true;
            this.cbTajm8.Enabled = false;
            this.cbTajm8.Location = new System.Drawing.Point(137, 117);
            this.cbTajm8.Name = "cbTajm8";
            this.cbTajm8.Size = new System.Drawing.Size(15, 14);
            this.cbTajm8.TabIndex = 27;
            this.cbTajm8.TabStop = false;
            this.cbTajm8.UseVisualStyleBackColor = true;
            this.cbTajm8.CheckedChanged += new System.EventHandler(this.checkBox7_CheckedChanged);
            // 
            // cbTajm7
            // 
            this.cbTajm7.AutoSize = true;
            this.cbTajm7.Enabled = false;
            this.cbTajm7.Location = new System.Drawing.Point(116, 117);
            this.cbTajm7.Name = "cbTajm7";
            this.cbTajm7.Size = new System.Drawing.Size(15, 14);
            this.cbTajm7.TabIndex = 28;
            this.cbTajm7.UseVisualStyleBackColor = true;
            this.cbTajm7.CheckedChanged += new System.EventHandler(this.cbTajm7_CheckedChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(9, 529);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 13);
            this.label18.TabIndex = 29;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(243, 660);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(82, 25);
            this.label19.TabIndex = 30;
            this.label19.Text = "Rezultat";
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(385, 847);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 34;
            this.button1.Text = "-1 POEN";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button2.Location = new System.Drawing.Point(438, 798);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 33;
            this.button2.Text = "3 POENA";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button3.Location = new System.Drawing.Point(438, 757);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 32;
            this.button3.Text = "2 POENA";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.button4.Location = new System.Drawing.Point(438, 717);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 31;
            this.button4.Text = "1 POEN";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(99, 21);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(80, 20);
            this.textBox3.TabIndex = 37;
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(258, 21);
            this.maskedTextBox1.Mask = "00/00/0000";
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(100, 20);
            this.maskedTextBox1.TabIndex = 38;
            this.maskedTextBox1.ValidatingType = typeof(System.DateTime);
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.Location = new System.Drawing.Point(439, 21);
            this.maskedTextBox2.Mask = "00:00";
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.Size = new System.Drawing.Size(33, 20);
            this.maskedTextBox2.TabIndex = 39;
            this.maskedTextBox2.ValidatingType = typeof(System.DateTime);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(142, 36);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(136, 20);
            this.textBox4.TabIndex = 40;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(55, 74);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(136, 20);
            this.textBox5.TabIndex = 41;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(256, 71);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(136, 20);
            this.textBox6.TabIndex = 42;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(99, 60);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(28, 20);
            this.textBox7.TabIndex = 43;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(278, 60);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(80, 20);
            this.textBox8.TabIndex = 44;
            // 
            // rtbB
            // 
            this.rtbB.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbB.Location = new System.Drawing.Point(315, 717);
            this.rtbB.Name = "rtbB";
            this.rtbB.ReadOnly = true;
            this.rtbB.Size = new System.Drawing.Size(94, 79);
            this.rtbB.TabIndex = 45;
            this.rtbB.Text = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dataGridView1);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.checkBox21);
            this.groupBox1.Controls.Add(this.cb4);
            this.groupBox1.Controls.Add(this.checkBox23);
            this.groupBox1.Controls.Add(this.checkBox24);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.checkBox17);
            this.groupBox1.Controls.Add(this.cb3);
            this.groupBox1.Controls.Add(this.checkBox19);
            this.groupBox1.Controls.Add(this.checkBox20);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.cb202);
            this.groupBox1.Controls.Add(this.cb204);
            this.groupBox1.Controls.Add(this.cb201);
            this.groupBox1.Controls.Add(this.cb203);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.cb02);
            this.groupBox1.Controls.Add(this.cb1);
            this.groupBox1.Controls.Add(this.cb01);
            this.groupBox1.Controls.Add(this.cb03);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.cbTajm1);
            this.groupBox1.Controls.Add(this.cbTajm2);
            this.groupBox1.Controls.Add(this.cbTajm3);
            this.groupBox1.Controls.Add(this.cbTajm4);
            this.groupBox1.Controls.Add(this.cbTajm5);
            this.groupBox1.Controls.Add(this.cbTajm6);
            this.groupBox1.Controls.Add(this.cbTajm8);
            this.groupBox1.Controls.Add(this.cbTajm7);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Location = new System.Drawing.Point(57, 200);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(634, 422);
            this.groupBox1.TabIndex = 46;
            this.groupBox1.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(27, 223);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(524, 197);
            this.dataGridView1.TabIndex = 84;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(474, 59);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(60, 13);
            this.label26.TabIndex = 53;
            this.label26.Text = "4. četvrtina";
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Enabled = false;
            this.checkBox21.Location = new System.Drawing.Point(490, 103);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(32, 17);
            this.checkBox21.TabIndex = 51;
            this.checkBox21.Text = "2";
            this.checkBox21.UseVisualStyleBackColor = true;
            // 
            // cb4
            // 
            this.cb4.AutoSize = true;
            this.cb4.Enabled = false;
            this.cb4.Location = new System.Drawing.Point(490, 149);
            this.cb4.Name = "cb4";
            this.cb4.Size = new System.Drawing.Size(32, 17);
            this.cb4.TabIndex = 52;
            this.cb4.Text = "4";
            this.cb4.UseVisualStyleBackColor = true;
            this.cb4.CheckedChanged += new System.EventHandler(this.cb4_CheckedChanged);
            // 
            // checkBox23
            // 
            this.checkBox23.AutoSize = true;
            this.checkBox23.Location = new System.Drawing.Point(490, 80);
            this.checkBox23.Name = "checkBox23";
            this.checkBox23.Size = new System.Drawing.Size(32, 17);
            this.checkBox23.TabIndex = 49;
            this.checkBox23.Text = "1";
            this.checkBox23.UseVisualStyleBackColor = true;
            // 
            // checkBox24
            // 
            this.checkBox24.AutoSize = true;
            this.checkBox24.Enabled = false;
            this.checkBox24.Location = new System.Drawing.Point(490, 126);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(32, 17);
            this.checkBox24.TabIndex = 50;
            this.checkBox24.Text = "3";
            this.checkBox24.UseVisualStyleBackColor = true;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(396, 59);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(60, 13);
            this.label25.TabIndex = 48;
            this.label25.Text = "3. četvrtina";
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Enabled = false;
            this.checkBox17.Location = new System.Drawing.Point(412, 103);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(32, 17);
            this.checkBox17.TabIndex = 46;
            this.checkBox17.Text = "2";
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // cb3
            // 
            this.cb3.AutoSize = true;
            this.cb3.Enabled = false;
            this.cb3.Location = new System.Drawing.Point(412, 149);
            this.cb3.Name = "cb3";
            this.cb3.Size = new System.Drawing.Size(32, 17);
            this.cb3.TabIndex = 47;
            this.cb3.Text = "4";
            this.cb3.UseVisualStyleBackColor = true;
            this.cb3.CheckedChanged += new System.EventHandler(this.cb3_CheckedChanged);
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Location = new System.Drawing.Point(412, 80);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(32, 17);
            this.checkBox19.TabIndex = 44;
            this.checkBox19.Text = "1";
            this.checkBox19.UseVisualStyleBackColor = true;
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Enabled = false;
            this.checkBox20.Location = new System.Drawing.Point(412, 126);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(32, 17);
            this.checkBox20.TabIndex = 45;
            this.checkBox20.Text = "3";
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(309, 58);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(60, 13);
            this.label24.TabIndex = 43;
            this.label24.Text = "2. četvrtina";
            // 
            // cb202
            // 
            this.cb202.AutoSize = true;
            this.cb202.Enabled = false;
            this.cb202.Location = new System.Drawing.Point(325, 102);
            this.cb202.Name = "cb202";
            this.cb202.Size = new System.Drawing.Size(32, 17);
            this.cb202.TabIndex = 41;
            this.cb202.Text = "2";
            this.cb202.UseVisualStyleBackColor = true;
            this.cb202.CheckedChanged += new System.EventHandler(this.cb202_CheckedChanged);
            // 
            // cb204
            // 
            this.cb204.AutoSize = true;
            this.cb204.Enabled = false;
            this.cb204.Location = new System.Drawing.Point(325, 148);
            this.cb204.Name = "cb204";
            this.cb204.Size = new System.Drawing.Size(32, 17);
            this.cb204.TabIndex = 42;
            this.cb204.Text = "4";
            this.cb204.UseVisualStyleBackColor = true;
            this.cb204.CheckedChanged += new System.EventHandler(this.cb2_CheckedChanged);
            // 
            // cb201
            // 
            this.cb201.AutoSize = true;
            this.cb201.Location = new System.Drawing.Point(325, 79);
            this.cb201.Name = "cb201";
            this.cb201.Size = new System.Drawing.Size(32, 17);
            this.cb201.TabIndex = 39;
            this.cb201.Text = "1";
            this.cb201.UseVisualStyleBackColor = true;
            this.cb201.CheckedChanged += new System.EventHandler(this.cb201_CheckedChanged);
            // 
            // cb203
            // 
            this.cb203.AutoSize = true;
            this.cb203.Enabled = false;
            this.cb203.Location = new System.Drawing.Point(325, 125);
            this.cb203.Name = "cb203";
            this.cb203.Size = new System.Drawing.Size(32, 17);
            this.cb203.TabIndex = 40;
            this.cb203.Text = "3";
            this.cb203.UseVisualStyleBackColor = true;
            this.cb203.CheckedChanged += new System.EventHandler(this.cb203_CheckedChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(220, 58);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(60, 13);
            this.label23.TabIndex = 38;
            this.label23.Text = "1. četvrtina";
            // 
            // cb02
            // 
            this.cb02.AutoSize = true;
            this.cb02.Enabled = false;
            this.cb02.Location = new System.Drawing.Point(236, 102);
            this.cb02.Name = "cb02";
            this.cb02.Size = new System.Drawing.Size(32, 17);
            this.cb02.TabIndex = 36;
            this.cb02.Text = "2";
            this.cb02.UseVisualStyleBackColor = true;
            this.cb02.CheckedChanged += new System.EventHandler(this.cb02_CheckedChanged);
            // 
            // cb1
            // 
            this.cb1.AutoSize = true;
            this.cb1.Enabled = false;
            this.cb1.Location = new System.Drawing.Point(236, 148);
            this.cb1.Name = "cb1";
            this.cb1.Size = new System.Drawing.Size(32, 17);
            this.cb1.TabIndex = 37;
            this.cb1.Text = "4";
            this.cb1.UseVisualStyleBackColor = true;
            this.cb1.CheckedChanged += new System.EventHandler(this.cb1_CheckedChanged);
            // 
            // cb01
            // 
            this.cb01.AutoSize = true;
            this.cb01.Location = new System.Drawing.Point(236, 79);
            this.cb01.Name = "cb01";
            this.cb01.Size = new System.Drawing.Size(32, 17);
            this.cb01.TabIndex = 33;
            this.cb01.Text = "1";
            this.cb01.UseVisualStyleBackColor = true;
            this.cb01.CheckedChanged += new System.EventHandler(this.checkBox9_CheckedChanged);
            // 
            // cb03
            // 
            this.cb03.AutoSize = true;
            this.cb03.Enabled = false;
            this.cb03.Location = new System.Drawing.Point(236, 125);
            this.cb03.Name = "cb03";
            this.cb03.Size = new System.Drawing.Size(32, 17);
            this.cb03.TabIndex = 34;
            this.cb03.Text = "3";
            this.cb03.UseVisualStyleBackColor = true;
            this.cb03.CheckedChanged += new System.EventHandler(this.cb03_CheckedChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(347, 16);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(70, 13);
            this.label22.TabIndex = 32;
            this.label22.Text = "Greške ekipe";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(24, 117);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 13);
            this.label21.TabIndex = 31;
            this.label21.Text = "produžetak";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(15, 93);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(68, 13);
            this.label20.TabIndex = 30;
            this.label20.Text = "2. poluvreme";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(15, 70);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(68, 13);
            this.label13.TabIndex = 29;
            this.label13.Text = "1. poluvreme";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.textBox8);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.textBox7);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.textBox3);
            this.groupBox2.Controls.Add(this.maskedTextBox1);
            this.groupBox2.Controls.Add(this.maskedTextBox2);
            this.groupBox2.Location = new System.Drawing.Point(133, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(484, 122);
            this.groupBox2.TabIndex = 47;
            this.groupBox2.TabStop = false;
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(180, 177);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(169, 20);
            this.textBox9.TabIndex = 48;
            // 
            // rtbPer1B
            // 
            this.rtbPer1B.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbPer1B.Location = new System.Drawing.Point(864, 714);
            this.rtbPer1B.Name = "rtbPer1B";
            this.rtbPer1B.ReadOnly = true;
            this.rtbPer1B.Size = new System.Drawing.Size(46, 24);
            this.rtbPer1B.TabIndex = 49;
            this.rtbPer1B.Text = "";
            this.rtbPer1B.TextChanged += new System.EventHandler(this.rtbPrvaCetA_TextChanged);
            // 
            // rtbPer1A
            // 
            this.rtbPer1A.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbPer1A.Location = new System.Drawing.Point(725, 714);
            this.rtbPer1A.Name = "rtbPer1A";
            this.rtbPer1A.ReadOnly = true;
            this.rtbPer1A.Size = new System.Drawing.Size(47, 24);
            this.rtbPer1A.TabIndex = 50;
            this.rtbPer1A.Text = "";
            this.rtbPer1A.TextChanged += new System.EventHandler(this.rtbPer1A_TextChanged);
            // 
            // cbprvacet
            // 
            this.cbprvacet.AutoSize = true;
            this.cbprvacet.Location = new System.Drawing.Point(233, 840);
            this.cbprvacet.Name = "cbprvacet";
            this.cbprvacet.Size = new System.Drawing.Size(112, 17);
            this.cbprvacet.TabIndex = 51;
            this.cbprvacet.Text = "Kraj prve četvrtine";
            this.cbprvacet.UseVisualStyleBackColor = true;
            this.cbprvacet.CheckedChanged += new System.EventHandler(this.cbprvacet_CheckedChanged);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(602, 717);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(46, 13);
            this.label27.TabIndex = 52;
            this.label27.Text = "Period 1";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(690, 717);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(14, 13);
            this.label28.TabIndex = 53;
            this.label28.Text = "A";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(832, 717);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(14, 13);
            this.label29.TabIndex = 54;
            this.label29.Text = "B";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(670, 660);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(224, 20);
            this.label30.TabIndex = 55;
            this.label30.Text = "Rezultati na kraju četrvtina";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(832, 759);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(14, 13);
            this.label32.TabIndex = 62;
            this.label32.Text = "B";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(690, 759);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(14, 13);
            this.label33.TabIndex = 61;
            this.label33.Text = "A";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(602, 759);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(46, 13);
            this.label34.TabIndex = 60;
            this.label34.Text = "Period 2";
            // 
            // rtbPer2A
            // 
            this.rtbPer2A.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbPer2A.Location = new System.Drawing.Point(725, 756);
            this.rtbPer2A.Name = "rtbPer2A";
            this.rtbPer2A.ReadOnly = true;
            this.rtbPer2A.Size = new System.Drawing.Size(47, 24);
            this.rtbPer2A.TabIndex = 59;
            this.rtbPer2A.Text = "";
            // 
            // rtbPer2B
            // 
            this.rtbPer2B.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbPer2B.Location = new System.Drawing.Point(864, 756);
            this.rtbPer2B.Name = "rtbPer2B";
            this.rtbPer2B.ReadOnly = true;
            this.rtbPer2B.Size = new System.Drawing.Size(46, 24);
            this.rtbPer2B.TabIndex = 58;
            this.rtbPer2B.Text = "";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(831, 806);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(14, 13);
            this.label35.TabIndex = 67;
            this.label35.Text = "B";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(689, 806);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(14, 13);
            this.label36.TabIndex = 66;
            this.label36.Text = "A";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(601, 806);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(46, 13);
            this.label37.TabIndex = 65;
            this.label37.Text = "Period 3";
            // 
            // rtbPer3A
            // 
            this.rtbPer3A.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbPer3A.Location = new System.Drawing.Point(725, 803);
            this.rtbPer3A.Name = "rtbPer3A";
            this.rtbPer3A.ReadOnly = true;
            this.rtbPer3A.Size = new System.Drawing.Size(47, 24);
            this.rtbPer3A.TabIndex = 64;
            this.rtbPer3A.Text = "";
            // 
            // rtbPer3B
            // 
            this.rtbPer3B.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbPer3B.Location = new System.Drawing.Point(863, 803);
            this.rtbPer3B.Name = "rtbPer3B";
            this.rtbPer3B.ReadOnly = true;
            this.rtbPer3B.Size = new System.Drawing.Size(46, 24);
            this.rtbPer3B.TabIndex = 63;
            this.rtbPer3B.Text = "";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(832, 851);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(14, 13);
            this.label38.TabIndex = 72;
            this.label38.Text = "B";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(690, 851);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(14, 13);
            this.label39.TabIndex = 71;
            this.label39.Text = "A";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(602, 851);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(46, 13);
            this.label40.TabIndex = 70;
            this.label40.Text = "Period 4";
            // 
            // rtbPer4A
            // 
            this.rtbPer4A.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbPer4A.Location = new System.Drawing.Point(725, 848);
            this.rtbPer4A.Name = "rtbPer4A";
            this.rtbPer4A.ReadOnly = true;
            this.rtbPer4A.Size = new System.Drawing.Size(47, 24);
            this.rtbPer4A.TabIndex = 69;
            this.rtbPer4A.Text = "";
            // 
            // rtbPer4B
            // 
            this.rtbPer4B.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbPer4B.Location = new System.Drawing.Point(864, 848);
            this.rtbPer4B.Name = "rtbPer4B";
            this.rtbPer4B.ReadOnly = true;
            this.rtbPer4B.Size = new System.Drawing.Size(46, 24);
            this.rtbPer4B.TabIndex = 68;
            this.rtbPer4B.Text = "";
            // 
            // cbDrugaCet
            // 
            this.cbDrugaCet.AutoSize = true;
            this.cbDrugaCet.Enabled = false;
            this.cbDrugaCet.Location = new System.Drawing.Point(233, 863);
            this.cbDrugaCet.Name = "cbDrugaCet";
            this.cbDrugaCet.Size = new System.Drawing.Size(118, 17);
            this.cbDrugaCet.TabIndex = 73;
            this.cbDrugaCet.Text = "Kraj druge četvrtine";
            this.cbDrugaCet.UseVisualStyleBackColor = true;
            this.cbDrugaCet.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // cbTrecaCet
            // 
            this.cbTrecaCet.AutoSize = true;
            this.cbTrecaCet.Enabled = false;
            this.cbTrecaCet.Location = new System.Drawing.Point(233, 886);
            this.cbTrecaCet.Name = "cbTrecaCet";
            this.cbTrecaCet.Size = new System.Drawing.Size(115, 17);
            this.cbTrecaCet.TabIndex = 74;
            this.cbTrecaCet.Text = "Kraj treće četvrtine";
            this.cbTrecaCet.UseVisualStyleBackColor = true;
            this.cbTrecaCet.CheckedChanged += new System.EventHandler(this.cbTrecaCet_CheckedChanged);
            // 
            // cbCetvrtaCet
            // 
            this.cbCetvrtaCet.AutoSize = true;
            this.cbCetvrtaCet.Enabled = false;
            this.cbCetvrtaCet.Location = new System.Drawing.Point(233, 909);
            this.cbCetvrtaCet.Name = "cbCetvrtaCet";
            this.cbCetvrtaCet.Size = new System.Drawing.Size(124, 17);
            this.cbCetvrtaCet.TabIndex = 75;
            this.cbCetvrtaCet.Text = "Kraj četvrte četvrtine";
            this.cbCetvrtaCet.UseVisualStyleBackColor = true;
            this.cbCetvrtaCet.CheckedChanged += new System.EventHandler(this.cbCetvrtaCet_CheckedChanged);
            // 
            // btnKonacanRez
            // 
            this.btnKonacanRez.Enabled = false;
            this.btnKonacanRez.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKonacanRez.Location = new System.Drawing.Point(220, 936);
            this.btnKonacanRez.Name = "btnKonacanRez";
            this.btnKonacanRez.Size = new System.Drawing.Size(137, 23);
            this.btnKonacanRez.TabIndex = 76;
            this.btnKonacanRez.Text = "Konačan rezultat";
            this.btnKonacanRez.UseVisualStyleBackColor = true;
            this.btnKonacanRez.Click += new System.EventHandler(this.btnKonacanRez_Click);
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(670, 963);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(145, 20);
            this.label41.TabIndex = 78;
            this.label41.Text = "Konačan rezultat";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(1053, 968);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(17, 17);
            this.label31.TabIndex = 82;
            this.label31.Text = "B";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(875, 968);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(17, 17);
            this.label42.TabIndex = 81;
            this.label42.Text = "A";
            // 
            // rtbKonacanA
            // 
            this.rtbKonacanA.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbKonacanA.Location = new System.Drawing.Point(927, 951);
            this.rtbKonacanA.Name = "rtbKonacanA";
            this.rtbKonacanA.ReadOnly = true;
            this.rtbKonacanA.Size = new System.Drawing.Size(101, 52);
            this.rtbKonacanA.TabIndex = 80;
            this.rtbKonacanA.Text = "";
            // 
            // rtbKonacanB
            // 
            this.rtbKonacanB.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbKonacanB.Location = new System.Drawing.Point(1097, 951);
            this.rtbKonacanB.Name = "rtbKonacanB";
            this.rtbKonacanB.ReadOnly = true;
            this.rtbKonacanB.Size = new System.Drawing.Size(101, 52);
            this.rtbKonacanB.TabIndex = 79;
            this.rtbKonacanB.Text = "";
            // 
            // btnZatvori
            // 
            this.btnZatvori.Location = new System.Drawing.Point(1347, 2);
            this.btnZatvori.Name = "btnZatvori";
            this.btnZatvori.Size = new System.Drawing.Size(75, 23);
            this.btnZatvori.TabIndex = 83;
            this.btnZatvori.Text = "Zatvori";
            this.btnZatvori.UseVisualStyleBackColor = true;
            this.btnZatvori.Click += new System.EventHandler(this.btnZatvori_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label5);
            this.groupBox3.Controls.Add(this.label14);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.textBox4);
            this.groupBox3.Controls.Add(this.textBox5);
            this.groupBox3.Controls.Add(this.textBox6);
            this.groupBox3.Location = new System.Drawing.Point(925, 12);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(397, 122);
            this.groupBox3.TabIndex = 84;
            this.groupBox3.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(964, 174);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(169, 20);
            this.textBox1.TabIndex = 87;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.dataGridView2);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.checkBox1);
            this.groupBox4.Controls.Add(this.checkBox2);
            this.groupBox4.Controls.Add(this.checkBox3);
            this.groupBox4.Controls.Add(this.checkBox4);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.checkBox5);
            this.groupBox4.Controls.Add(this.checkBox6);
            this.groupBox4.Controls.Add(this.checkBox7);
            this.groupBox4.Controls.Add(this.checkBox8);
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.checkBox9);
            this.groupBox4.Controls.Add(this.checkBox10);
            this.groupBox4.Controls.Add(this.checkBox11);
            this.groupBox4.Controls.Add(this.checkBox12);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.checkBox14);
            this.groupBox4.Controls.Add(this.checkBox18);
            this.groupBox4.Controls.Add(this.checkBox22);
            this.groupBox4.Controls.Add(this.checkBox25);
            this.groupBox4.Controls.Add(this.label43);
            this.groupBox4.Controls.Add(this.label44);
            this.groupBox4.Controls.Add(this.label45);
            this.groupBox4.Controls.Add(this.label46);
            this.groupBox4.Controls.Add(this.label47);
            this.groupBox4.Controls.Add(this.checkBox26);
            this.groupBox4.Controls.Add(this.checkBox27);
            this.groupBox4.Controls.Add(this.checkBox28);
            this.groupBox4.Controls.Add(this.checkBox29);
            this.groupBox4.Controls.Add(this.checkBox30);
            this.groupBox4.Controls.Add(this.checkBox31);
            this.groupBox4.Controls.Add(this.checkBox32);
            this.groupBox4.Controls.Add(this.checkBox33);
            this.groupBox4.Controls.Add(this.label48);
            this.groupBox4.Location = new System.Drawing.Point(864, 200);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(634, 422);
            this.groupBox4.TabIndex = 86;
            this.groupBox4.TabStop = false;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(27, 223);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(524, 193);
            this.dataGridView2.TabIndex = 84;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(474, 59);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 13);
            this.label1.TabIndex = 53;
            this.label1.Text = "4. četvrtina";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Enabled = false;
            this.checkBox1.Location = new System.Drawing.Point(490, 103);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(32, 17);
            this.checkBox1.TabIndex = 51;
            this.checkBox1.Text = "2";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Enabled = false;
            this.checkBox2.Location = new System.Drawing.Point(490, 149);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(32, 17);
            this.checkBox2.TabIndex = 52;
            this.checkBox2.Text = "4";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(490, 80);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(32, 17);
            this.checkBox3.TabIndex = 49;
            this.checkBox3.Text = "1";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Enabled = false;
            this.checkBox4.Location = new System.Drawing.Point(490, 126);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(32, 17);
            this.checkBox4.TabIndex = 50;
            this.checkBox4.Text = "3";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(396, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(60, 13);
            this.label3.TabIndex = 48;
            this.label3.Text = "3. četvrtina";
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Enabled = false;
            this.checkBox5.Location = new System.Drawing.Point(412, 103);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(32, 17);
            this.checkBox5.TabIndex = 46;
            this.checkBox5.Text = "2";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Enabled = false;
            this.checkBox6.Location = new System.Drawing.Point(412, 149);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(32, 17);
            this.checkBox6.TabIndex = 47;
            this.checkBox6.Text = "4";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(412, 80);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(32, 17);
            this.checkBox7.TabIndex = 44;
            this.checkBox7.Text = "1";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Enabled = false;
            this.checkBox8.Location = new System.Drawing.Point(412, 126);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(32, 17);
            this.checkBox8.TabIndex = 45;
            this.checkBox8.Text = "3";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(309, 58);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(60, 13);
            this.label4.TabIndex = 43;
            this.label4.Text = "2. četvrtina";
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Enabled = false;
            this.checkBox9.Location = new System.Drawing.Point(325, 102);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(32, 17);
            this.checkBox9.TabIndex = 41;
            this.checkBox9.Text = "2";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Enabled = false;
            this.checkBox10.Location = new System.Drawing.Point(325, 148);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(32, 17);
            this.checkBox10.TabIndex = 42;
            this.checkBox10.Text = "4";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(325, 79);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(32, 17);
            this.checkBox11.TabIndex = 39;
            this.checkBox11.Text = "1";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Enabled = false;
            this.checkBox12.Location = new System.Drawing.Point(325, 125);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(32, 17);
            this.checkBox12.TabIndex = 40;
            this.checkBox12.Text = "3";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(220, 58);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(60, 13);
            this.label16.TabIndex = 38;
            this.label16.Text = "1. četvrtina";
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Enabled = false;
            this.checkBox14.Location = new System.Drawing.Point(236, 102);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(32, 17);
            this.checkBox14.TabIndex = 36;
            this.checkBox14.Text = "2";
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Enabled = false;
            this.checkBox18.Location = new System.Drawing.Point(236, 148);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(32, 17);
            this.checkBox18.TabIndex = 37;
            this.checkBox18.Text = "4";
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // checkBox22
            // 
            this.checkBox22.AutoSize = true;
            this.checkBox22.Location = new System.Drawing.Point(236, 79);
            this.checkBox22.Name = "checkBox22";
            this.checkBox22.Size = new System.Drawing.Size(32, 17);
            this.checkBox22.TabIndex = 33;
            this.checkBox22.Text = "1";
            this.checkBox22.UseVisualStyleBackColor = true;
            // 
            // checkBox25
            // 
            this.checkBox25.AutoSize = true;
            this.checkBox25.Enabled = false;
            this.checkBox25.Location = new System.Drawing.Point(236, 125);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(32, 17);
            this.checkBox25.TabIndex = 34;
            this.checkBox25.Text = "3";
            this.checkBox25.UseVisualStyleBackColor = true;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(347, 16);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(70, 13);
            this.label43.TabIndex = 32;
            this.label43.Text = "Greške ekipe";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(24, 117);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(60, 13);
            this.label44.TabIndex = 31;
            this.label44.Text = "produžetak";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(15, 93);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(68, 13);
            this.label45.TabIndex = 30;
            this.label45.Text = "2. poluvreme";
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Location = new System.Drawing.Point(15, 70);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(68, 13);
            this.label46.TabIndex = 29;
            this.label46.Text = "1. poluvreme";
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(39, 16);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(50, 13);
            this.label47.TabIndex = 7;
            this.label47.Text = "Tajm-auti";
            // 
            // checkBox26
            // 
            this.checkBox26.AutoSize = true;
            this.checkBox26.Location = new System.Drawing.Point(95, 70);
            this.checkBox26.Name = "checkBox26";
            this.checkBox26.Size = new System.Drawing.Size(15, 14);
            this.checkBox26.TabIndex = 21;
            this.checkBox26.UseVisualStyleBackColor = true;
            // 
            // checkBox27
            // 
            this.checkBox27.AutoSize = true;
            this.checkBox27.Enabled = false;
            this.checkBox27.Location = new System.Drawing.Point(116, 70);
            this.checkBox27.Name = "checkBox27";
            this.checkBox27.Size = new System.Drawing.Size(15, 14);
            this.checkBox27.TabIndex = 22;
            this.checkBox27.UseVisualStyleBackColor = true;
            // 
            // checkBox28
            // 
            this.checkBox28.AutoSize = true;
            this.checkBox28.Location = new System.Drawing.Point(95, 93);
            this.checkBox28.Name = "checkBox28";
            this.checkBox28.Size = new System.Drawing.Size(15, 14);
            this.checkBox28.TabIndex = 23;
            this.checkBox28.UseVisualStyleBackColor = true;
            // 
            // checkBox29
            // 
            this.checkBox29.AutoSize = true;
            this.checkBox29.Enabled = false;
            this.checkBox29.Location = new System.Drawing.Point(116, 94);
            this.checkBox29.Name = "checkBox29";
            this.checkBox29.Size = new System.Drawing.Size(15, 14);
            this.checkBox29.TabIndex = 24;
            this.checkBox29.UseVisualStyleBackColor = true;
            // 
            // checkBox30
            // 
            this.checkBox30.AutoSize = true;
            this.checkBox30.Enabled = false;
            this.checkBox30.Location = new System.Drawing.Point(137, 94);
            this.checkBox30.Name = "checkBox30";
            this.checkBox30.Size = new System.Drawing.Size(15, 14);
            this.checkBox30.TabIndex = 25;
            this.checkBox30.UseVisualStyleBackColor = true;
            // 
            // checkBox31
            // 
            this.checkBox31.AutoSize = true;
            this.checkBox31.Location = new System.Drawing.Point(95, 117);
            this.checkBox31.Name = "checkBox31";
            this.checkBox31.Size = new System.Drawing.Size(15, 14);
            this.checkBox31.TabIndex = 26;
            this.checkBox31.UseVisualStyleBackColor = true;
            // 
            // checkBox32
            // 
            this.checkBox32.AutoSize = true;
            this.checkBox32.Enabled = false;
            this.checkBox32.Location = new System.Drawing.Point(137, 117);
            this.checkBox32.Name = "checkBox32";
            this.checkBox32.Size = new System.Drawing.Size(15, 14);
            this.checkBox32.TabIndex = 27;
            this.checkBox32.TabStop = false;
            this.checkBox32.UseVisualStyleBackColor = true;
            // 
            // checkBox33
            // 
            this.checkBox33.AutoSize = true;
            this.checkBox33.Enabled = false;
            this.checkBox33.Location = new System.Drawing.Point(116, 117);
            this.checkBox33.Name = "checkBox33";
            this.checkBox33.Size = new System.Drawing.Size(15, 14);
            this.checkBox33.TabIndex = 28;
            this.checkBox33.UseVisualStyleBackColor = true;
            // 
            // label48
            // 
            this.label48.AccessibleRole = System.Windows.Forms.AccessibleRole.Cursor;
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(232, 179);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(48, 20);
            this.label48.TabIndex = 8;
            this.label48.Text = "Igrači";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(878, 170);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(64, 20);
            this.label49.TabIndex = 85;
            this.label49.Text = "Ekipa B";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(480, 909);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 88;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click_3);
            // 
            // rtbPrvaCetA
            // 
            this.rtbPrvaCetA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbPrvaCetA.Location = new System.Drawing.Point(1067, 712);
            this.rtbPrvaCetA.Name = "rtbPrvaCetA";
            this.rtbPrvaCetA.ReadOnly = true;
            this.rtbPrvaCetA.Size = new System.Drawing.Size(50, 24);
            this.rtbPrvaCetA.TabIndex = 89;
            this.rtbPrvaCetA.Text = "";
            // 
            // rtbDrugaCetA
            // 
            this.rtbDrugaCetA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbDrugaCetA.Location = new System.Drawing.Point(1067, 752);
            this.rtbDrugaCetA.Name = "rtbDrugaCetA";
            this.rtbDrugaCetA.ReadOnly = true;
            this.rtbDrugaCetA.Size = new System.Drawing.Size(50, 24);
            this.rtbDrugaCetA.TabIndex = 90;
            this.rtbDrugaCetA.Text = "";
            // 
            // rtbCetvrtaCetA
            // 
            this.rtbCetvrtaCetA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbCetvrtaCetA.Location = new System.Drawing.Point(1067, 840);
            this.rtbCetvrtaCetA.Name = "rtbCetvrtaCetA";
            this.rtbCetvrtaCetA.ReadOnly = true;
            this.rtbCetvrtaCetA.Size = new System.Drawing.Size(50, 24);
            this.rtbCetvrtaCetA.TabIndex = 91;
            this.rtbCetvrtaCetA.Text = "";
            // 
            // rtbTrecaCetA
            // 
            this.rtbTrecaCetA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbTrecaCetA.Location = new System.Drawing.Point(1067, 793);
            this.rtbTrecaCetA.Name = "rtbTrecaCetA";
            this.rtbTrecaCetA.ReadOnly = true;
            this.rtbTrecaCetA.Size = new System.Drawing.Size(50, 24);
            this.rtbTrecaCetA.TabIndex = 92;
            this.rtbTrecaCetA.Text = "";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(1081, 660);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(204, 20);
            this.label50.TabIndex = 93;
            this.label50.Text = "Rezultati po četvrtinama";
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(1039, 720);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(14, 13);
            this.label51.TabIndex = 95;
            this.label51.Text = "A";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(1207, 841);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(14, 13);
            this.label52.TabIndex = 103;
            this.label52.Text = "B";
            // 
            // rtbCetvrtaCetB
            // 
            this.rtbCetvrtaCetB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbCetvrtaCetB.Location = new System.Drawing.Point(1235, 836);
            this.rtbCetvrtaCetB.Name = "rtbCetvrtaCetB";
            this.rtbCetvrtaCetB.ReadOnly = true;
            this.rtbCetvrtaCetB.Size = new System.Drawing.Size(50, 24);
            this.rtbCetvrtaCetB.TabIndex = 102;
            this.rtbCetvrtaCetB.Text = "";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(1207, 798);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(14, 13);
            this.label53.TabIndex = 101;
            this.label53.Text = "B";
            // 
            // rtbTrecaCetB
            // 
            this.rtbTrecaCetB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbTrecaCetB.Location = new System.Drawing.Point(1235, 793);
            this.rtbTrecaCetB.Name = "rtbTrecaCetB";
            this.rtbTrecaCetB.ReadOnly = true;
            this.rtbTrecaCetB.Size = new System.Drawing.Size(50, 24);
            this.rtbTrecaCetB.TabIndex = 100;
            this.rtbTrecaCetB.Text = "";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(1207, 759);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(14, 13);
            this.label54.TabIndex = 99;
            this.label54.Text = "B";
            // 
            // rtbDrugaCetB
            // 
            this.rtbDrugaCetB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbDrugaCetB.Location = new System.Drawing.Point(1235, 754);
            this.rtbDrugaCetB.Name = "rtbDrugaCetB";
            this.rtbDrugaCetB.ReadOnly = true;
            this.rtbDrugaCetB.Size = new System.Drawing.Size(50, 24);
            this.rtbDrugaCetB.TabIndex = 98;
            this.rtbDrugaCetB.Text = "";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(1207, 717);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(14, 13);
            this.label55.TabIndex = 97;
            this.label55.Text = "B";
            // 
            // rtbPrvaCetB
            // 
            this.rtbPrvaCetB.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtbPrvaCetB.Location = new System.Drawing.Point(1235, 712);
            this.rtbPrvaCetB.Name = "rtbPrvaCetB";
            this.rtbPrvaCetB.ReadOnly = true;
            this.rtbPrvaCetB.Size = new System.Drawing.Size(50, 24);
            this.rtbPrvaCetB.TabIndex = 96;
            this.rtbPrvaCetB.Text = "";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(1039, 759);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(14, 13);
            this.label56.TabIndex = 104;
            this.label56.Text = "A";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(1039, 798);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(14, 13);
            this.label57.TabIndex = 105;
            this.label57.Text = "A";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(1039, 845);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(14, 13);
            this.label58.TabIndex = 106;
            this.label58.Text = "A";
            // 
            // Zapisnik
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1434, 1084);
            this.ControlBox = false;
            this.Controls.Add(this.label58);
            this.Controls.Add(this.label57);
            this.Controls.Add(this.label56);
            this.Controls.Add(this.label52);
            this.Controls.Add(this.rtbCetvrtaCetB);
            this.Controls.Add(this.label53);
            this.Controls.Add(this.rtbTrecaCetB);
            this.Controls.Add(this.label54);
            this.Controls.Add(this.rtbDrugaCetB);
            this.Controls.Add(this.label55);
            this.Controls.Add(this.rtbPrvaCetB);
            this.Controls.Add(this.label51);
            this.Controls.Add(this.label50);
            this.Controls.Add(this.rtbTrecaCetA);
            this.Controls.Add(this.rtbCetvrtaCetA);
            this.Controls.Add(this.rtbDrugaCetA);
            this.Controls.Add(this.rtbPrvaCetA);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.btnZatvori);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.rtbKonacanA);
            this.Controls.Add(this.rtbKonacanB);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.btnKonacanRez);
            this.Controls.Add(this.cbCetvrtaCet);
            this.Controls.Add(this.cbTrecaCet);
            this.Controls.Add(this.cbDrugaCet);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.rtbPer4A);
            this.Controls.Add(this.rtbPer4B);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.rtbPer3A);
            this.Controls.Add(this.rtbPer3B);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.rtbPer2A);
            this.Controls.Add(this.rtbPer2B);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.cbprvacet);
            this.Controls.Add(this.rtbPer1A);
            this.Controls.Add(this.rtbPer1B);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.rtbB);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.btnPonistiPoenA);
            this.Controls.Add(this.btn3poenaA);
            this.Controls.Add(this.btn2poenaA);
            this.Controls.Add(this.btn1poenA);
            this.Controls.Add(this.rtbA);
            this.Name = "Zapisnik";
            this.Load += new System.EventHandler(this.Zapisnik_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.RichTextBox rtbA;
        private System.Windows.Forms.Button btn1poenA;
        private System.Windows.Forms.Button btn2poenaA;
        private System.Windows.Forms.Button btn3poenaA;
        private System.Windows.Forms.Button btnPonistiPoenA;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.CheckBox cbTajm1;
        private System.Windows.Forms.CheckBox cbTajm2;
        private System.Windows.Forms.CheckBox cbTajm3;
        private System.Windows.Forms.CheckBox cbTajm4;
        private System.Windows.Forms.CheckBox cbTajm5;
        private System.Windows.Forms.CheckBox cbTajm6;
        private System.Windows.Forms.CheckBox cbTajm8;
        private System.Windows.Forms.CheckBox cbTajm7;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.RichTextBox rtbB;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.CheckBox checkBox21;
        private System.Windows.Forms.CheckBox cb4;
        private System.Windows.Forms.CheckBox checkBox23;
        private System.Windows.Forms.CheckBox checkBox24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.CheckBox checkBox17;
        private System.Windows.Forms.CheckBox cb3;
        private System.Windows.Forms.CheckBox checkBox19;
        private System.Windows.Forms.CheckBox checkBox20;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.CheckBox cb202;
        private System.Windows.Forms.CheckBox cb204;
        private System.Windows.Forms.CheckBox cb201;
        private System.Windows.Forms.CheckBox cb203;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.CheckBox cb02;
        private System.Windows.Forms.CheckBox cb1;
        private System.Windows.Forms.CheckBox cb01;
        private System.Windows.Forms.CheckBox cb03;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.RichTextBox rtbPer1B;
        private System.Windows.Forms.RichTextBox rtbPer1A;
        private System.Windows.Forms.CheckBox cbprvacet;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.RichTextBox rtbPer2A;
        private System.Windows.Forms.RichTextBox rtbPer2B;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.RichTextBox rtbPer3A;
        private System.Windows.Forms.RichTextBox rtbPer3B;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.RichTextBox rtbPer4A;
        private System.Windows.Forms.RichTextBox rtbPer4B;
        private System.Windows.Forms.CheckBox cbDrugaCet;
        private System.Windows.Forms.CheckBox cbTrecaCet;
        private System.Windows.Forms.CheckBox cbCetvrtaCet;
        private System.Windows.Forms.Button btnKonacanRez;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.RichTextBox rtbKonacanA;
        private System.Windows.Forms.RichTextBox rtbKonacanB;
        private System.Windows.Forms.Button btnZatvori;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.CheckBox checkBox18;
        private System.Windows.Forms.CheckBox checkBox22;
        private System.Windows.Forms.CheckBox checkBox25;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.CheckBox checkBox26;
        private System.Windows.Forms.CheckBox checkBox27;
        private System.Windows.Forms.CheckBox checkBox28;
        private System.Windows.Forms.CheckBox checkBox29;
        private System.Windows.Forms.CheckBox checkBox30;
        private System.Windows.Forms.CheckBox checkBox31;
        private System.Windows.Forms.CheckBox checkBox32;
        private System.Windows.Forms.CheckBox checkBox33;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.RichTextBox rtbPrvaCetA;
        private System.Windows.Forms.RichTextBox rtbDrugaCetA;
        private System.Windows.Forms.RichTextBox rtbCetvrtaCetA;
        private System.Windows.Forms.RichTextBox rtbTrecaCetA;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.RichTextBox rtbCetvrtaCetB;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.RichTextBox rtbTrecaCetB;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.RichTextBox rtbDrugaCetB;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.RichTextBox rtbPrvaCetB;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
    }
}

