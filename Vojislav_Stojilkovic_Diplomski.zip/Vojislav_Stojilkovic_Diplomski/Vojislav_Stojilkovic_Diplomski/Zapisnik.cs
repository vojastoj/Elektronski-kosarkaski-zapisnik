﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

namespace Vojislav_Stojilkovic_Diplomski
{
    public partial class Zapisnik : Form
    {
        int rez = 0;
        int rez2 = 0;
        string nula = "0";

        public Zapisnik()


        {
            InitializeComponent();
        }

        private void napuni1()
        {



        }
        private void btn1poenA_Click(object sender, EventArgs e)
        {
            rtbA.Clear();
            rtbA.AppendText(Convert.ToInt32(rez += 1).ToString());

        }

        private void btn2poenaA_Click(object sender, EventArgs e)
        {
            rtbA.Clear();
            rtbA.AppendText(Convert.ToInt32(rez += 2).ToString());
        }

        private void btn3poenaA_Click(object sender, EventArgs e)
        {
            rtbA.Clear();
            rtbA.AppendText(Convert.ToInt32(rez += 3).ToString());
        }

        private void Negativno()
        {
            if (rez < 0) { MessageBox.Show("Rezultat ne može biti u minusu.", "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error); rtbA.Clear(); }
            if (rez2 < 0)
            {
                MessageBox.Show("Rezultat ne može biti u minusu.", "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error);
                rtbB.Clear();
            }
        }
        private void btnPonistiPoenA_Click(object sender, EventArgs e)
        {

            if (rtbA.Text == String.Empty) { MessageBox.Show("Rezultat ne može biti u minusu.", "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            else
            {


                rtbA.Clear();
                rtbA.AppendText(Convert.ToInt32(rez -= 1).ToString());
                Negativno();


            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            rtbB.Clear();
            rtbB.AppendText(Convert.ToInt32(rez2 += 1).ToString());

        }

        private void button3_Click(object sender, EventArgs e)
        {
            rtbB.Clear();
            rtbB.AppendText(Convert.ToInt32(rez2 += 2).ToString());
        }

        private void button2_Click(object sender, EventArgs e)
        {
            rtbB.Clear();
            rtbB.AppendText(Convert.ToInt32(rez2 += 3).ToString());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (rtbB.Text == String.Empty) { MessageBox.Show("Rezultat ne može biti u minusu.", "Greška", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            else
            {

                rtbB.Clear();
                rtbB.AppendText(Convert.ToInt32(rez2 -= 1).ToString());
                Negativno();
            }
        }

        private void Bonus()
        {
            if (cb1.Checked == true) { MessageBox.Show("Ekipa A je ispunila bonus!", "BONUS", MessageBoxButtons.OK, MessageBoxIcon.Information); }
        }
        private void cb1_CheckedChanged(object sender, EventArgs e)
        {
            if (cb1.Checked == true) { MessageBox.Show("Ekipa A je ispunila bonus!", "BONUS", MessageBoxButtons.OK, MessageBoxIcon.Information); }
        }

        private void cb2_CheckedChanged(object sender, EventArgs e)
        {
            if (cb204.Checked == true)
            {
                MessageBox.Show("Ekipa A je ispunila bonus!", "BONUS", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void cb3_CheckedChanged(object sender, EventArgs e)
        {
            if (cb3.Checked == true)
            {
                MessageBox.Show("Ekipa A je ispunila bonus!", "BONUS", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void cb4_CheckedChanged(object sender, EventArgs e)
        {
            if (cb4.Checked == true)
            {
                MessageBox.Show("Ekipa A je ispunila bonus!", "BONUS", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            if (cb01.Checked == true) { cb02.Enabled = true; }
            else
            {
                cb02.Enabled = false;
            }
        }

        private void cb02_CheckedChanged(object sender, EventArgs e)
        {
            if (cb02.Checked == true) { cb03.Enabled = true; }
            else
            {
                cb03.Enabled = false;
            }
        }

        private void cb03_CheckedChanged(object sender, EventArgs e)
        {
            if (cb03.Checked == true) { cb1.Enabled = true; }
            else
            {
                cb1.Enabled = false;
            }
        }

        private void cbTajm1_CheckedChanged(object sender, EventArgs e)
        {
            if (cbTajm1.Checked == true) { cbTajm2.Enabled = true; }
            else
            {
                cbTajm2.Enabled = false;
            }
        }

        private void cbTajm3_CheckedChanged(object sender, EventArgs e)
        {
            if (cbTajm3.Checked == true) { cbTajm4.Enabled = true; }
            else
            {
                cbTajm4.Enabled = false;
            }
        }

        private void cbTajm4_CheckedChanged(object sender, EventArgs e)
        {
            if (cbTajm4.Checked == true) { cbTajm5.Enabled = true; }
            else
            {
                cbTajm5.Enabled = false;
            }
        }

        private void cbTajm2_CheckedChanged(object sender, EventArgs e)
        {
            if (cbTajm2.Checked == true) { MessageBox.Show("Ekipa A je iskoristila sve tajm-aut-ove u prvom poluvremenu.", "Tajm-aut", MessageBoxButtons.OK, MessageBoxIcon.Information); }
        }

        private void cbTajm5_CheckedChanged(object sender, EventArgs e)
        {
            if (cbTajm5.Checked == true) { MessageBox.Show("Ekipa A je iskoristila sve tajm-aut-ove u drugom poluvremenu.", "Tajm-aut", MessageBoxButtons.OK, MessageBoxIcon.Information); }
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            if (cbTajm8.Checked == true) { MessageBox.Show("Ekipa A je iskoristila sve tajm-aut-ove u produžetku.", "Tajm-aut", MessageBoxButtons.OK, MessageBoxIcon.Information); }
        }

        private void cbTajm6_CheckedChanged(object sender, EventArgs e)
        {
            if (cbTajm6.Checked == true) { cbTajm7.Enabled = true; }
            else
            {
                cbTajm7.Enabled = false;
            }
        }

        private void cbTajm7_CheckedChanged(object sender, EventArgs e)
        {
            if (cbTajm7.Checked == true) { cbTajm8.Enabled = true; }
            else
            {
                cbTajm8.Enabled = false;
            }
        }

        private void cbprvacet_CheckedChanged(object sender, EventArgs e)
        {
            if (cbprvacet.Checked == true && rtbA.Text == String.Empty) { rtbPer1A.AppendText(nula); }
            if (cbprvacet.Checked == true && rtbB.Text == String.Empty) { rtbPer1B.AppendText(nula); }
            if (cbprvacet.Checked == true) { rtbPer1A.AppendText(rtbA.Text); rtbPer1B.AppendText(rtbB.Text); cbDrugaCet.Enabled = true; RezCet(); }
            else
            {
                cbDrugaCet.Enabled = false;
                rtbPer1B.Clear();
                rtbPer1A.Clear();
            }
        }

        private void rtbPrvaCetA_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

            if (cbDrugaCet.Checked == true) { rtbPer2A.AppendText(rtbA.Text); rtbPer2B.AppendText(rtbB.Text); cbTrecaCet.Enabled = true; RezCet2(); }
            else
            {
                cbTrecaCet.Enabled = false;
                rtbPer2A.Clear();
                rtbPer2B.Clear();
            }

        }

        private void cbTrecaCet_CheckedChanged(object sender, EventArgs e)
        {
            if (cbTrecaCet.Checked == true) { rtbPer3A.AppendText(rtbA.Text); rtbPer3B.AppendText(rtbB.Text); cbCetvrtaCet.Enabled = true; RezCet3(); }
            else
            {
                cbCetvrtaCet.Enabled = false;
                rtbPer3A.Clear();
                rtbPer3B.Clear();
            }
        }

        private void cbCetvrtaCet_CheckedChanged(object sender, EventArgs e)
        {
            if (cbCetvrtaCet.Checked == true)
            {
                rtbPer4A.AppendText(rtbA.Text); rtbPer4B.AppendText(rtbB.Text); btnKonacanRez.Enabled = true; btn1poenA.Enabled = false;
                btn2poenaA.Enabled = false;
                btn3poenaA.Enabled = false;
                btnPonistiPoenA.Enabled = false;
                button4.Enabled = false;
                button2.Enabled = false;
                button3.Enabled = false;
                button1.Enabled = false;
                cbprvacet.Enabled = false;
                cbDrugaCet.Enabled = false;
                cbTrecaCet.Enabled = false;
                RezCet4();


            }
            else
            {
                btn1poenA.Enabled = true;
                btn2poenaA.Enabled = true;
                btn3poenaA.Enabled = true;
                btnPonistiPoenA.Enabled = true;
                button4.Enabled = true;
                button2.Enabled = true;
                button3.Enabled = true;
                button1.Enabled = true;
                cbprvacet.Enabled = true;
                cbDrugaCet.Enabled = true;
                cbTrecaCet.Enabled = true;

                btnKonacanRez.Enabled = false;
                rtbPer4A.Clear();
                rtbPer4B.Clear();
            }
        }

        private void btnZatvori_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnKonacanRez_Click(object sender, EventArgs e)
        {
            btn1poenA.Enabled = false;
            btn2poenaA.Enabled = false;
            btn3poenaA.Enabled = false;
            btnPonistiPoenA.Enabled = false;
            button4.Enabled = false;
            button2.Enabled = false;
            button3.Enabled = false;
            button1.Enabled = false;
            cbprvacet.Enabled = false;
            cbDrugaCet.Enabled = false;
            cbTrecaCet.Enabled = false;
            cbCetvrtaCet.Enabled = false;
            rtbKonacanA.AppendText(rtbA.Text);
            rtbKonacanB.AppendText(rtbB.Text);
        }

        private void label52_Click(object sender, EventArgs e)
        {
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click_1(object sender, EventArgs e)
        {


        }

        private void button5_Click_2(object sender, EventArgs e)
        {

        }
        private void RezCet()
        {
            rtbPrvaCetA.AppendText(Convert.ToInt32(rez).ToString());
            rtbPrvaCetB.AppendText(Convert.ToInt32(rez2).ToString());

        }
        private void RezCet2()
        {
            int rr = rez;
            int rrB = rez2;
            rtbDrugaCetA.AppendText(Convert.ToInt32(rr -= Convert.ToInt32(rtbPer1A.Text)).ToString());
            rtbDrugaCetB.AppendText(Convert.ToInt32(rrB -= Convert.ToInt32(rtbPer1B.Text)).ToString());
        }
        private void RezCet3()
        {
            

            int rrB2 = rez2;
            int rr1 = rez;
            rtbTrecaCetA.AppendText(Convert.ToInt32(rr1 -= Convert.ToInt32(rtbPer2A.Text)).ToString());
            rtbTrecaCetB.AppendText(Convert.ToInt32(rrB2 -= Convert.ToInt32(rtbPer2B.Text)).ToString());
        }
        private void RezCet4()
        {
            int rrB3 = rez2;
            int rr2 = rez;
            rtbCetvrtaCetA.AppendText(Convert.ToInt32(rr2 -= Convert.ToInt32(rtbPer3A.Text)).ToString());
            rtbCetvrtaCetB.AppendText(Convert.ToInt32(rrB3 -= Convert.ToInt32(rtbPer3B.Text)).ToString());
        }

        private void button5_Click_3(object sender, EventArgs e)
        {
            /** rtbA.Clear();
             rtbB.Clear();
             rtbPer1A.Clear();
             rtbPer2A.Clear();
             rtbPer3A.Clear();
             rtbPer4A.Clear();
             rtbPer1B.Clear();
             rtbPer2B.Clear();
             rtbPer3B.Clear();
             rtbPer4B.Clear();
             rtbPrvaCetA.Clear();
             rtbDrugaCetA.Clear();
             rtbTrecaCetA.Clear();
             rtbCetvrtaCetA.Clear();
             rtbPrvaCetB.Clear();
             rtbDrugaCetB.Clear();
             rtbTrecaCetB.Clear();
             rtbCetvrtaCetB.Clear();
             cbprvacet.Checked = false;
             cbDrugaCet.Checked = false;
             cbTrecaCet.Checked = false;
             cbCetvrtaCet.Checked = false;
             cbCetvrtaCet.Enabled = false;
             cbDrugaCet.Enabled = false;
             cbTrecaCet.Enabled = false;**/



        }

        private void rtbPer1A_TextChanged(object sender, EventArgs e)
        {

        }

        private void Zapisnik_Load(object sender, EventArgs e)
        {

        }

        private void cb201_CheckedChanged(object sender, EventArgs e)
        {
            if (cb201.Checked == true) { cb202.Enabled = true; } else { cb202.Enabled = false; }
        }

        

        private void cb202_CheckedChanged(object sender, EventArgs e)
        {
            if (cb202.Checked == true) { cb203.Enabled = true; } else { cb203.Enabled = false; }
        }

        private void cb203_CheckedChanged(object sender, EventArgs e)
        {
            if (cb203.Checked == true) { cb204.Enabled = true; } else { cb204.Enabled = false; }
        }
    }
}
